/**
 * Lakbay | Screen 6: Travel Plan Summary
 * Day-by-day summary, print, and summary action buttons.
 */
'use strict';

/* ==========================================================================
   SCREEN 6: TRAVEL PLAN SUMMARY (Day-by-Day, Export JSON, Copy Plan, Print)
   ========================================================================== */
function setupSummaryControls() {
  const copyBtn = document.getElementById('btn-summary-copy-plan');
  const exportBtn = document.getElementById('btn-summary-export-json');

  if (copyBtn) {
    copyBtn.addEventListener('click', copyPlanAsText);
  }

  if (exportBtn) {
    exportBtn.addEventListener('click', exportJSON);
  }
}

function buildSummary() {
  const reportCard = document.getElementById('summary-report-card');
  const emptyState = document.getElementById('summary-empty-state');

  const stops = appState.itinerary;
  const trip = appState.trip;

  const hasData = stops.length > 0 || appState.hasConfirmedBudget;

  if (!hasData) {
    if (reportCard) reportCard.style.display = 'none';
    if (emptyState) emptyState.style.display = 'block';
    return;
  }

  if (emptyState) emptyState.style.display = 'none';
  if (reportCard) reportCard.style.display = 'block';

  // 1. Meta Details
  const metaDays = document.getElementById('summary-meta-days');
  const metaTravelers = document.getElementById('summary-meta-travelers');
  const metaStops = document.getElementById('summary-meta-stops-count');

  const daysCount = trip.days || appState.budget.days || 2;
  const nightsCount = Math.max(1, daysCount - 1);
  const travelersCount = appState.budget.travelers || 1;

  if (metaDays) metaDays.textContent = `${daysCount} Day${daysCount === 1 ? '' : 's'} (${nightsCount} Night${nightsCount === 1 ? '' : 's'})`;
  if (metaTravelers) metaTravelers.textContent = `${travelersCount} Person${travelersCount === 1 ? '' : 's'}`;
  if (metaStops) metaStops.textContent = `${stops.length} Stop${stops.length === 1 ? '' : 's'}`;

  // 3. Day-by-Day Itinerary Schedule with Per-Day Subtotals
  const itineraryContainer = document.getElementById('summary-itinerary-list');
  if (itineraryContainer) {
    if (stops.length === 0) {
      itineraryContainer.innerHTML = '<span class="summary-empty-note">No planned stops yet.</span>';
    } else {
      const uniqueDates = [...new Set(stops.map(s => s.date))].sort();
      itineraryContainer.innerHTML = uniqueDates.map((dateStr, idx) => {
        const dayStops = stops.filter(s => s.date === dateStr);
        const dayNumber = idx + 1;
        const formattedDate = formatDate(dateStr);
        const dayFees = dayStops.reduce((sum, s) => sum + (Number(s.fee) || 0), 0);

        return `
          <article class="summary-day-card">
            <div class="summary-day-head">
              <span class="summary-day-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
              </span>
              <span class="summary-day-title">Day ${dayNumber} · ${formattedDate}</span>
              <span class="summary-day-stat">${dayStops.length} Stop${dayStops.length === 1 ? '' : 's'} · ₱${formatNumber(dayFees)} Fees</span>
            </div>
            <div class="summary-day-stops">
              ${dayStops.map(stop => {
                const duration = stop.duration || 90;
                const startMins = timeToMinutes(stop.time);
                const endMins = startMins + duration;
                const rangeStr = `${stop.time} – ${minutesToTime(endMins)}`;

                return `
                  <div class="summary-itinerary-item">
                    <span class="summary-time-tag">${rangeStr}</span>
                    <span class="summary-itinerary-text">
                      <strong>${escapeHTML(stop.destinationName)}</strong>${stop.activity && stop.activity.trim() ? `<span class="summary-stop-activity">: ${escapeHTML(stop.activity)}</span>` : ''}
                      <span class="summary-fee-pill">${stop.fee > 0 ? `₱${formatNumber(stop.fee)}` : 'Free'}</span>
                    </span>
                  </div>
                `;
              }).join('')}
            </div>
          </article>
        `;
      }).join('');
    }
  }

  // 4. Budget Breakdown (Calculated from Itinerary Budget Selection)
  const costTrans = document.getElementById('summary-cost-trans');
  const costAcc = document.getElementById('summary-cost-acc');
  const costFood = document.getElementById('summary-cost-food');
  const costAct = document.getElementById('summary-cost-activities');
  const costExtra = document.getElementById('summary-cost-extra');
  const costTotal = document.getElementById('summary-cost-total');
  const costPerPerson = document.getElementById('summary-cost-per-person');
  const costTravelers = document.getElementById('summary-cost-travelers');

  const maxBudget = trip.budgetMax || 3500;
  const lodging = Math.round(maxBudget * 0.40);
  const food = Math.round(maxBudget * 0.25);
  const transpo = Math.round(maxBudget * 0.15);
  const stopsFees = stops.reduce((sum, s) => sum + (Number(s.fee) || 0), 0);
  const other = Math.round(maxBudget * 0.10);

  if (costTrans) costTrans.textContent = formatCurrency(transpo);
  if (costAcc) costAcc.textContent = formatCurrency(lodging);
  if (costFood) costFood.textContent = formatCurrency(food);
  if (costAct) costAct.textContent = formatCurrency(stopsFees);
  if (costExtra) costExtra.textContent = formatCurrency(other);
  if (costTotal) costTotal.textContent = `₱${formatNumber(trip.budgetMin || 1500)} – ₱${formatNumber(maxBudget)}`;
  if (costPerPerson) costPerPerson.textContent = `₱${formatNumber(trip.budgetMin || 1500)} – ₱${formatNumber(maxBudget)}`;
  if (costTravelers) costTravelers.textContent = travelersCount;
}

const generateSummary = buildSummary;

